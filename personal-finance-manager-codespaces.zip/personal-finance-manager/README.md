# Pennywise — Personal Finance Manager

A responsive React + Vite starter app for tracking income, expenses and category budgets. It uses browser `localStorage`; no account, API key or backend is required.

## Run in GitHub Codespaces

1. Create a new GitHub repository and upload this project (or use **Add file → Upload files**).
2. Open the repository, select **Code → Codespaces → Create codespace on main**.
3. In the Codespaces terminal run:

   ```bash
   npm install
   npm run dev
   ```

4. When Codespaces offers to open port **5173**, choose **Open in Browser**. If it does not, open the **Ports** tab and forward port 5173.

## Features

- Overview cards for balance, income, expenses and savings rate.
- Cash-flow chart and spending-by-category donut chart.
- Add income or expense records with date, category and note.
- Search and delete transactions.
- Category budget progress, including over-budget state.
- Responsive sidebar and mobile layout.
- Automatic local persistence using browser localStorage.

## Project structure

```text
personal-finance-manager/
├── index.html              # HTML page and React mount point
├── package.json            # Dependencies and npm scripts
├── vite.config.js          # Vite React plugin configuration
├── README.md
└── src/
    ├── main.jsx            # React entry point; mounts App
    ├── App.jsx             # Layout, state, views, charts and UI components
    ├── data.js             # Demo transactions, budgets and GBP formatter
    └── styles.css          # Responsive visual styling
```

## How it works

1. `main.jsx` mounts the root React component into `#root`.
2. `App` loads saved transactions and budgets from `localStorage`; if none exist, it uses sample data from `data.js`.
3. React state (`useState`) is the source of truth while the app is open. `useEffect` writes changes back to local storage.
4. `useMemo` calculates totals and category spending from transactions.
5. The Overview uses Recharts `AreaChart` and `PieChart` to visualize the data.
6. The Add Transaction modal validates the form and passes a new record to `App`. The parent updates state, which refreshes the totals, charts and lists.
7. Transactions can be searched and deleted. Budget bars compare recorded expenses with each category's configured limit.

## Main components

- **App** — owns application state, persistence, calculations, navigation and page composition.
- **StatCard** — reusable summary tile for a financial metric.
- **TransactionList** — renders transaction rows; receives data and a delete callback through props.
- **AddTransaction** — controlled form modal; validates input and calls `onAdd`.
- **Overview view** — composes summary cards, cash-flow chart, spending breakdown and recent activity.
- **Transactions view** — searchable complete transaction list.
- **Budgets view** — shows category spend against budget limits.
- **data.js** — seed data and currency formatting helper.

## Important notes / next steps

- The chart's six-month cash-flow series is illustrative demo data. Replace `chartData` in `src/App.jsx` with monthly totals calculated from real transactions before relying on it.
- The sample transactions are fictional. This is a learning/demo app, not a regulated financial product.
- Data is stored only in the current browser profile. Clearing site data removes it; it does not sync across devices.
- For a production version, add authentication, a secure backend/database, server-side validation, encrypted transport, backups, tests and a privacy policy. Never put banking credentials or secret API keys in frontend code.
- To reset the demo, clear local storage for the Codespaces preview origin (browser developer tools → Application/Storage → Local Storage).
